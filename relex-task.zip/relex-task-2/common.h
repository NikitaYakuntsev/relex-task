//
// Created by kit on 23.06.15.
//

#ifndef RELEX_TASK_COMMON_H
#define RELEX_TASK_COMMON_H
#include <string>
#include <sstream>
#include <vector>
#include <map>
extern const unsigned int MINUTE;
#endif //RELEX_TASK_COMMON_H
