#include <iostream>

using namespace std;

#include "common.h"
#include "Gardener.h"
int main() {
    Gardener gardener;
    gardener.startWork();
    return 0;
}