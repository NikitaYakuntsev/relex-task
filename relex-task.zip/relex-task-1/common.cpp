//
// Created by kit on 23.06.15.
//

#include "common.h"
const unsigned int MINUTE = 60;